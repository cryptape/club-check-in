const userContract = "0xF9ff25565DA5d29358E98763Ed66387e7D5c19d7";
const tokenContract = "0x51bc03805f2b5d436643cbbdb96399607976b455";
const clubContract = "0x514b5fEEFC6eBc21A1c59ce9237490E1b13074a1";
const dataContract = "0x8c6daE4432B2cEaE9deAEaDfE210B4d316BCa6e1";
const ownerAddress = "0x46a23E25df9A0F6c18729ddA9Ad1aF3b6A131160";

module.exports = {
  userContract,
  tokenContract,
  clubContract,
  dataContract,
  ownerAddress
};
