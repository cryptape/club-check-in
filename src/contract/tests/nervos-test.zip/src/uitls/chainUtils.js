import transaction from "./transaction.js";
const nervos = require("../nervos");

export const getTX = () =>
  nervos.appchain.getBlockNumber().then(current => {
    const tx = {
      ...transaction,
      from: "0x46a23E25df9A0F6c18729ddA9Ad1aF3b6A131160",
      validUntilBlock: +current + 88,
      privateKey:
        "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
    };
    // const tx = {
    //   ...transaction,
    //   from: window.neuron.getAccount(),
    //   validUntilBlock: +current + 88
    // };
    return tx;
  });

export const TXManager = method => {
  return new Promise((resolve, reject) => {
    getTX().then(tx => {
      txListener(method, tx, resolve, reject);
    });
  });
};

export const txListener = function(method, tx, resolve, reject) {
  method
    .send(tx)
    .then(res => {
      console.log(res);
      if (res.hash) {
        window.nervos.listeners
          .listenToTransactionReceipt(res.hash)
          .then(receipt => {
            if (!receipt.errorMessage) {
              resolve(receipt);
            } else {
              reject(receipt.errorMessage);
            }
          })
          .catch(err => {
            console.log(err);
            reject(err);
          });
      } else {
        reject("No Transaction Hash Received");
      }
    })
    .catch(err => {
      reject(err);
    });
};

export const deploy = async function(args, abi, bytecode) {
  return new Promise((resolve, reject) => {
    getTX()
      .then(tx => {
        console.log(abi);
        const contract = new window.nervos.appchain.Contract(abi);
        contract
          .deploy({ data: bytecode, arguments: args })
          .send(tx)
          .then(res => {
            console.log(res);
            if (res.hash) {
              return window.nervos.listeners
                .listenToTransactionReceipt(res.hash)
                .then(receipt => {
                  console.log(JSON.stringify(receipt));
                  if (!receipt.errorMessage) {
                    resolve(receipt);
                  } else {
                    reject(receipt.errorMessage);
                  }
                });
            } else {
              reject("No Transaction Hash Received");
            }
          })
          .catch(err => {
            console.log(err);
            reject(err.errorMessage);
          });
      })
      .catch(err => {
        console.log(err);
        reject(err.errorMessage);
      });
  });
};
