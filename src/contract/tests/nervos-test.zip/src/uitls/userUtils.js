import { getTX, txListener } from "./chainUtils";
import { abi } from "../contract/playStore";
import { userContract } from "../contract/baseAddress";
const nervos = require("../nervos");

export const getPlayerAddress = async function(sender) {
  return new Promise((resolve, reject) => {
    let contract = new window.nervos.appchain.Contract(abi, userContract);
    contract.methods
      .getPlayerAddress(sender)
      .call()
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const getPlayer = async function(sender) {
  return new Promise((resolve, reject) => {
    let contract = new window.nervos.appchain.Contract(abi, userContract);
    contract.methods
      .players(sender)
      .call()
      .then(res => {
        resolve(res);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const signIn = async function(name, icon) {
  return new Promise((resolve, reject) => {
    getTX()
      .then(tx => {
        txListener(
          getContract().methods.signIn(name, icon),
          tx,
          resolve,
          reject
        );
      })
      .catch(err => {
        reject(err);
      });
  });
};

const getContract = () => {
  return new nervos.appchain.Contract(abi, userContract);
};
