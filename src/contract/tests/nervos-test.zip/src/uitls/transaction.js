
const transaction = {
    nonce: 999999,
    quota: 1000000000,
    chainId: 1,
    version: 0,
    validUntilBlock: 999999,
};

module.exports = transaction
