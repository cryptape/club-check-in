/**
 * Created by 包俊 on 2018/9/5.
 */
import React from "react";
import { deploy } from "./uitls/chainUtils.js";
import { abi, bytecode } from "./contract/proxyStore";
import { getPlayerAddress, signIn, getPlayer } from "./uitls/userUtils";

import {
  userContract,
  clubContract,
  tokenContract,
  dataContract,
  ownerAddress
} from "./contract/baseAddress.js";

export default class App extends React.Component {
  render() {
    return (
      <div style={Styles.Container}>
        <button style={Styles.Button} onClick={() => this.deploy()}>
          deploy
        </button>
        <button style={Styles.Button} onClick={() => this.sign()}>
          signIn
        </button>
        <button style={Styles.Button} onClick={() => this.getPlayerAddress()}>
          getPlayerAddress
        </button>
      </div>
    );
  }

  deploy() {
    deploy(
      [clubContract, tokenContract, userContract, "qwe", "qwe", 10, 1, 1, 1],
      // [tokenContract],
      // [],
      abi,
      bytecode
    )
      .then(res => {
        console.log(res);
      })
      .catch(err => {
        console.log(err);
      });
  }

  sign() {
    signIn("baojun", "")
      .then(res => console.log(res))
      .catch(error => console.log(error));
  }

  getPlayerAddress() {
    getPlayer("0x46a23E25df9A0F6c18729ddA9Ad1aF3b6A131160")
      .then(res => console.log(res))
      .catch(error => console.log(error));
  }
}

const Styles = {
  Container: {
    display: "flex",
    flexDirection: "column",
    flex: 1
  },
  Button: {
    width: "100px"
  }
};
